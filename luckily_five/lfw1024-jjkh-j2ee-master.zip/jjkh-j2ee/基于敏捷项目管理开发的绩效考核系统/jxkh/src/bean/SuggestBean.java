package bean;

public class SuggestBean {
	public String getmID() {
		return mID;
	}
	public void setmID(String mID) {
		this.mID = mID;
	}
	public String getMstuID() {
		return mstuID;
	}
	public void setMstuID(String mstuID) {
		this.mstuID = mstuID;
	}
	public String getMteaID() {
		return mteaID;
	}
	public void setMteaID(String mteaID) {
		this.mteaID = mteaID;
	}
	public String getMess() {
		return mess;
	}
	public void setMess(String mess) {
		this.mess = mess;
	}
	public String getMdate() {
		return mdate;
	}
	public void setMdate(String mdate) {
		this.mdate = mdate;
	}
	private String mID;
	private String mstuID;
	private String mteaID;
	private String mess;
	private String mdate;
}
