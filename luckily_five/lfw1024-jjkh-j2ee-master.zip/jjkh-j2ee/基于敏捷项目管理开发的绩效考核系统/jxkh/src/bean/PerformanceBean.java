package bean;

public class PerformanceBean {
	private String perfName;
	private String perfClass;
	private int perfID;
	public int getPerfID() {
		return perfID;
	}
	public void setPerfID(int perfID) {
		this.perfID = perfID;
	}
	public String getPerfName() {
		return perfName;
	}
	public void setPerfName(String perfName) {
		this.perfName = perfName;
	}
	public String getPerfClass() {
		return perfClass;
	}
	public void setPerfClass(String perfClass) {
		this.perfClass = perfClass;
	}
	
	
}