package bean;

public class IndexTeacherBean {

	public String getTeaName() {
		return teaName;
	}
	public void setTeaName(String teaName) {
		this.teaName = teaName;
	}
	public String getPerfname() {
		return Perfname;
	}
	public void setPerfname(String perfname) {
		Perfname = perfname;
	}
	public String getScore() {
		return Score;
	}
	public void setScore(String score) {
		Score = score;
	}
	private String teaName;
	private String Perfname;
	private String Score;

	
}