package bean;

public class IndexAdminBean {


	public String getTeaId() {
		return teaId;
	}
	public void setTeaId(String teaId) {
		this.teaId = teaId;
	}
	public String getTeaName() {
		return teaName;
	}
	public void setTeaName(String teaName) {
		this.teaName = teaName;
	}
	public String getTeaSex() {
		return teaSex;
	}
	public void setTeaSex(String teaSex) {
		this.teaSex = teaSex;
	}
	public String getTeaSdept() {
		return teaSdept;
	}
	public void setTeaSdept(String teaSdept) {
		this.teaSdept = teaSdept;
	}
	public String getScores() {
		return Scores;
	}
	public void setScores(String scores) {
		Scores = scores;
	}
	private String teaId;
	private String teaName;
	private String teaSex;
	private String teaSdept;
	private String Scores;
	
}