package bean;

public class Student {
	public String getSno() {
		return Sno;
	}
	public void setSno(String sno) {
		Sno = sno;
	}
	public String getSname() {
		return Sname;
	}
	public void setSname(String sname) {
		Sname = sname;
	}
	public String getSpw() {
		return Spw;
	}
	public void setSpw(String spw) {
		Spw = spw;
	}
	public String getSex() {
		return Sex;
	}
	public void setSex(String sex) {
		Sex = sex;
	}
	public String getSclass() {
		return Sclass;
	}
	public void setSclass(String sclass) {
		Sclass = sclass;
	}
	private String Sno;
	private String Sname;
	private String Spw;
	private String Sex;
	private String Sclass;
	
}
