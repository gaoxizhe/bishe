/*
Navicat MySQL Data Transfer

Source Server         : q
Source Server Version : 50534
Source Host           : localhost:3306
Source Database       : jxkh

Target Server Type    : MYSQL
Target Server Version : 50534
File Encoding         : 65001

Date: 2014-05-17 14:41:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `adminID` varchar(255) NOT NULL COMMENT '管理员编号',
  `adminPW` varchar(255) NOT NULL DEFAULT '12345' COMMENT '管理员密码',
  `adminName` varchar(255) NOT NULL COMMENT '管理员姓名',
  PRIMARY KEY (`adminID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('12345600000', 'admin', '管理员');
INSERT INTO `admin` VALUES ('22222200000', '12345', '超级管理员');

-- ----------------------------
-- Table structure for `classes`
-- ----------------------------
DROP TABLE IF EXISTS `classes`;
CREATE TABLE `classes` (
  `Cno` varchar(20) NOT NULL COMMENT '课号',
  `Cname` varchar(20) NOT NULL COMMENT '课名',
  `Tno` varchar(20) DEFAULT NULL COMMENT '任课老师编号',
  `Score` int(11) NOT NULL DEFAULT '1' COMMENT '课程学分',
  PRIMARY KEY (`Cno`),
  KEY `T_CKEY` (`Tno`),
  CONSTRAINT `T_CKEY` FOREIGN KEY (`Tno`) REFERENCES `teacher` (`teaId`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of classes
-- ----------------------------
INSERT INTO `classes` VALUES ('111111', '辅导员', '11201335', '1');
INSERT INTO `classes` VALUES ('123400', 'FLASH设计', '10201316', '4');
INSERT INTO `classes` VALUES ('123411', '大型数据库技术', '10120131', '3');
INSERT INTO `classes` VALUES ('123412', '软件测试技术', '10120111', '4');
INSERT INTO `classes` VALUES ('123413', '英语', '10121313', '2');
INSERT INTO `classes` VALUES ('123415', '软件项目管理', '10121314', '5');
INSERT INTO `classes` VALUES ('123434', '数学', '10201315', '2');

-- ----------------------------
-- Table structure for `counts`
-- ----------------------------
DROP TABLE IF EXISTS `counts`;
CREATE TABLE `counts` (
  `id` int(11) NOT NULL,
  `PerfID` int(11) NOT NULL,
  `TeaID` varchar(255) DEFAULT NULL,
  `Scores` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of counts
-- ----------------------------

-- ----------------------------
-- Table structure for `notice`
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL COMMENT '公告标题',
  `content` varchar(200) NOT NULL COMMENT '内容',
  `ident` varchar(10) NOT NULL COMMENT '类别标识',
  `dates` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES ('1', '五一放假', '五一放假五一放假五一放假五一放假', '学生', '2014-05-08 01:14:42');
INSERT INTO `notice` VALUES ('7', '标题1', '标题+内容=表内<img alt=\"羡慕\" src=\"script/xheditor_emot/default/envy.gif\" />', '学生', '2014-04-25 00:18:59');
INSERT INTO `notice` VALUES ('9', '地点', '地点', '学生', '2014-05-08 01:15:07');
INSERT INTO `notice` VALUES ('10', 'x鑫鑫', '<span style=\"font-family:KaiTi_GB2312;\">最好的</span><span style=\"font-family:SimHei;color:#ff0000;\">泡沫</span>', '全体师生', '2014-04-25 00:20:03');
INSERT INTO `notice` VALUES ('15', '呵呵', '呵呵呵呵呵', '教师', '2014-04-29 18:23:24');
INSERT INTO `notice` VALUES ('16', '五一放假', '<p>五一放假好几天</p><p><br /></p><p align=\"right\">2013-1-2<br /></p>', '全体师生', '2014-05-08 01:14:24');
INSERT INTO `notice` VALUES ('17', '5.8', 'dddd', '全体师生', '2014-05-08 11:09:32');

-- ----------------------------
-- Table structure for `performance`
-- ----------------------------
DROP TABLE IF EXISTS `performance`;
CREATE TABLE `performance` (
  `perfID` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `perfName` varchar(100) NOT NULL COMMENT '考核名称',
  `perfClass` varchar(100) DEFAULT NULL COMMENT '绩效类别',
  PRIMARY KEY (`perfID`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of performance
-- ----------------------------
INSERT INTO `performance` VALUES ('123', '教师出勤情况', '1');
INSERT INTO `performance` VALUES ('124', '作业批改情况', '2');
INSERT INTO `performance` VALUES ('125', '组织学生学习', '3');
INSERT INTO `performance` VALUES ('126', '教职工周工作量', '4');
INSERT INTO `performance` VALUES ('127', '教师师德表现', '1');
INSERT INTO `performance` VALUES ('129', '教师工作态度', '2');

-- ----------------------------
-- Table structure for `rawdata`
-- ----------------------------
DROP TABLE IF EXISTS `rawdata`;
CREATE TABLE `rawdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '原数据',
  `StuID` varchar(20) NOT NULL,
  `TeaID` varchar(20) NOT NULL,
  `PerfID` int(11) NOT NULL COMMENT '项目编号',
  `Score` int(11) NOT NULL COMMENT '得分',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of rawdata
-- ----------------------------
INSERT INTO `rawdata` VALUES ('15', '1321145109', '11201318', '125', '1');
INSERT INTO `rawdata` VALUES ('16', '1321145106', '10120111', '123', '6');
INSERT INTO `rawdata` VALUES ('17', '1321145106', '10120111', '124', '4');
INSERT INTO `rawdata` VALUES ('18', '1321145106', '10120111', '125', '6');
INSERT INTO `rawdata` VALUES ('19', '1321145106', '10120131', '123', '6');
INSERT INTO `rawdata` VALUES ('20', '1321145106', '10120131', '124', '7');
INSERT INTO `rawdata` VALUES ('21', '1321145106', '10120131', '125', '7');
INSERT INTO `rawdata` VALUES ('28', '1321145107', '10121313', '123', '7');
INSERT INTO `rawdata` VALUES ('29', '1321145107', '10121313', '124', '6');
INSERT INTO `rawdata` VALUES ('30', '1321145107', '10121313', '125', '6');
INSERT INTO `rawdata` VALUES ('31', '1321145106', '10121313', '123', '10');
INSERT INTO `rawdata` VALUES ('32', '1321145106', '10121313', '124', '10');
INSERT INTO `rawdata` VALUES ('33', '1321145106', '10121313', '125', '0');
INSERT INTO `rawdata` VALUES ('34', '1321145106', '10121314', '123', '0');
INSERT INTO `rawdata` VALUES ('35', '1321145106', '10121314', '124', '6');
INSERT INTO `rawdata` VALUES ('36', '1321145106', '10121314', '125', '0');
INSERT INTO `rawdata` VALUES ('37', '1321145107', '10120111', '123', '6');
INSERT INTO `rawdata` VALUES ('38', '1321145107', '10120111', '124', '0');
INSERT INTO `rawdata` VALUES ('39', '1321145107', '10120111', '125', '0');
INSERT INTO `rawdata` VALUES ('40', '1321145108', '10120111', '123', '8');
INSERT INTO `rawdata` VALUES ('41', '1321145108', '10120111', '124', '0');
INSERT INTO `rawdata` VALUES ('42', '1321145108', '10120111', '125', '0');
INSERT INTO `rawdata` VALUES ('43', '1321145108', '10120131', '123', '0');
INSERT INTO `rawdata` VALUES ('44', '1321145108', '10120131', '124', '0');
INSERT INTO `rawdata` VALUES ('45', '1321145108', '10120131', '125', '0');
INSERT INTO `rawdata` VALUES ('46', '1321145108', '10121313', '123', '0');
INSERT INTO `rawdata` VALUES ('47', '1321145108', '10121313', '124', '0');
INSERT INTO `rawdata` VALUES ('48', '1321145108', '10121313', '125', '0');
INSERT INTO `rawdata` VALUES ('64', '1321145518', '10120111', '123', '6');
INSERT INTO `rawdata` VALUES ('65', '1321145518', '10120111', '124', '4');
INSERT INTO `rawdata` VALUES ('66', '1321145518', '10120111', '125', '4');
INSERT INTO `rawdata` VALUES ('67', '1321145518', '10121314', '123', '10');
INSERT INTO `rawdata` VALUES ('68', '1321145518', '10121314', '124', '5');
INSERT INTO `rawdata` VALUES ('69', '1321145518', '10121314', '125', '7');
INSERT INTO `rawdata` VALUES ('70', '1321145518', '10120131', '123', '7');
INSERT INTO `rawdata` VALUES ('71', '1321145518', '10120131', '124', '7');
INSERT INTO `rawdata` VALUES ('72', '1321145518', '10120131', '125', '4');
INSERT INTO `rawdata` VALUES ('73', '1321145518', '10201315', '123', '3');
INSERT INTO `rawdata` VALUES ('74', '1321145518', '10201315', '124', '9');
INSERT INTO `rawdata` VALUES ('75', '1321145518', '10201315', '125', '4');
INSERT INTO `rawdata` VALUES ('76', '1321145518', '10121313', '123', '3');
INSERT INTO `rawdata` VALUES ('77', '1321145518', '10121313', '124', '3');
INSERT INTO `rawdata` VALUES ('78', '1321145518', '10121313', '125', '2');
INSERT INTO `rawdata` VALUES ('79', '1321145518', '10201316', '123', '6');
INSERT INTO `rawdata` VALUES ('80', '1321145518', '10201316', '124', '6');
INSERT INTO `rawdata` VALUES ('81', '1321145518', '10201316', '125', '5');
INSERT INTO `rawdata` VALUES ('82', '1321145518', '10201316', '126', '5');
INSERT INTO `rawdata` VALUES ('83', '1321145518', '10201316', '127', '5');
INSERT INTO `rawdata` VALUES ('84', '1321145518', '10201316', '129', '5');
INSERT INTO `rawdata` VALUES ('85', '1321145406', '10120111', '123', '7');
INSERT INTO `rawdata` VALUES ('86', '1321145406', '10120111', '124', '7');
INSERT INTO `rawdata` VALUES ('87', '1321145406', '10120111', '125', '8');
INSERT INTO `rawdata` VALUES ('88', '1321145406', '10120111', '126', '8');
INSERT INTO `rawdata` VALUES ('89', '1321145406', '10120111', '127', '5');
INSERT INTO `rawdata` VALUES ('90', '1321145406', '10120111', '129', '4');
INSERT INTO `rawdata` VALUES ('91', '1321145518', '11201335', '123', '9');
INSERT INTO `rawdata` VALUES ('92', '1321145518', '11201335', '124', '9');
INSERT INTO `rawdata` VALUES ('93', '1321145518', '11201335', '125', '9');
INSERT INTO `rawdata` VALUES ('94', '1321145518', '11201335', '126', '8');
INSERT INTO `rawdata` VALUES ('95', '1321145518', '11201335', '127', '6');
INSERT INTO `rawdata` VALUES ('96', '1321145518', '11201335', '129', '6');
INSERT INTO `rawdata` VALUES ('97', '1321145312', '10120111', '123', '2');
INSERT INTO `rawdata` VALUES ('98', '1321145312', '10120111', '124', '10');
INSERT INTO `rawdata` VALUES ('99', '1321145312', '10120111', '125', '10');
INSERT INTO `rawdata` VALUES ('100', '1321145312', '10120111', '126', '10');
INSERT INTO `rawdata` VALUES ('101', '1321145312', '10120111', '127', '10');
INSERT INTO `rawdata` VALUES ('102', '1321145312', '10120111', '129', '10');
INSERT INTO `rawdata` VALUES ('103', '1321145626', '10120131', '123', '8');
INSERT INTO `rawdata` VALUES ('104', '1321145626', '10120131', '124', '7');
INSERT INTO `rawdata` VALUES ('105', '1321145626', '10120131', '125', '5');
INSERT INTO `rawdata` VALUES ('106', '1321145626', '10120131', '126', '5');
INSERT INTO `rawdata` VALUES ('107', '1321145626', '10120131', '127', '6');
INSERT INTO `rawdata` VALUES ('108', '1321145626', '10120131', '129', '3');
INSERT INTO `rawdata` VALUES ('109', '1321145626', '10120111', '123', '4');
INSERT INTO `rawdata` VALUES ('110', '1321145626', '10120111', '124', '5');
INSERT INTO `rawdata` VALUES ('111', '1321145626', '10120111', '125', '3');
INSERT INTO `rawdata` VALUES ('112', '1321145626', '10120111', '126', '3');
INSERT INTO `rawdata` VALUES ('113', '1321145626', '10120111', '127', '2');
INSERT INTO `rawdata` VALUES ('114', '1321145626', '10120111', '129', '4');
INSERT INTO `rawdata` VALUES ('115', '1321145407', '10120131', '123', '8');
INSERT INTO `rawdata` VALUES ('116', '1321145407', '10120131', '124', '7');
INSERT INTO `rawdata` VALUES ('117', '1321145407', '10120131', '125', '6');
INSERT INTO `rawdata` VALUES ('118', '1321145407', '10120131', '126', '8');
INSERT INTO `rawdata` VALUES ('119', '1321145407', '10120131', '127', '8');
INSERT INTO `rawdata` VALUES ('120', '1321145407', '10120131', '129', '10');

-- ----------------------------
-- Table structure for `sclass`
-- ----------------------------
DROP TABLE IF EXISTS `sclass`;
CREATE TABLE `sclass` (
  `SCid` int(11) NOT NULL AUTO_INCREMENT COMMENT '选课编号',
  `StuId` varchar(20) DEFAULT NULL COMMENT '学号',
  `ClassId` varchar(20) DEFAULT NULL COMMENT '课程号',
  PRIMARY KEY (`SCid`),
  KEY `Stu_id` (`StuId`),
  KEY `Cl_id` (`ClassId`),
  CONSTRAINT `Cl_id` FOREIGN KEY (`ClassId`) REFERENCES `classes` (`Cno`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Stu_id` FOREIGN KEY (`StuId`) REFERENCES `student` (`Sno`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1323 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sclass
-- ----------------------------
INSERT INTO `sclass` VALUES ('1000', '1321145518', '123412');
INSERT INTO `sclass` VALUES ('1001', '1321145518', '123411');
INSERT INTO `sclass` VALUES ('1002', '1321145518', '123415');
INSERT INTO `sclass` VALUES ('1003', '1321145518', '123413');
INSERT INTO `sclass` VALUES ('1004', '1321145518', '123434');
INSERT INTO `sclass` VALUES ('1005', '1321145106', '123411');
INSERT INTO `sclass` VALUES ('1006', '1321145106', '123412');
INSERT INTO `sclass` VALUES ('1007', '1321145106', '123413');
INSERT INTO `sclass` VALUES ('1008', '1321145106', '123415');
INSERT INTO `sclass` VALUES ('1009', '1321145518', '123400');
INSERT INTO `sclass` VALUES ('1010', null, '123411');
INSERT INTO `sclass` VALUES ('1011', null, '123412');
INSERT INTO `sclass` VALUES ('1012', null, '123413');
INSERT INTO `sclass` VALUES ('1013', null, '123415');
INSERT INTO `sclass` VALUES ('1014', null, '123434');
INSERT INTO `sclass` VALUES ('1015', '1321145108', '123411');
INSERT INTO `sclass` VALUES ('1016', '1321145108', '123412');
INSERT INTO `sclass` VALUES ('1017', '1321145108', '123413');
INSERT INTO `sclass` VALUES ('1018', '1321145108', '123415');
INSERT INTO `sclass` VALUES ('1019', '1321145108', '123434');
INSERT INTO `sclass` VALUES ('1020', '1321145109', '123411');
INSERT INTO `sclass` VALUES ('1021', '1321145109', '123412');
INSERT INTO `sclass` VALUES ('1022', '1321145109', '123413');
INSERT INTO `sclass` VALUES ('1023', '1321145109', '123415');
INSERT INTO `sclass` VALUES ('1024', '1321145109', '123434');
INSERT INTO `sclass` VALUES ('1025', null, '123411');
INSERT INTO `sclass` VALUES ('1026', null, '123412');
INSERT INTO `sclass` VALUES ('1027', null, '123413');
INSERT INTO `sclass` VALUES ('1028', null, '123415');
INSERT INTO `sclass` VALUES ('1029', null, '123434');
INSERT INTO `sclass` VALUES ('1030', '1321145111', '123411');
INSERT INTO `sclass` VALUES ('1031', '1321145111', '123412');
INSERT INTO `sclass` VALUES ('1032', '1321145111', '123413');
INSERT INTO `sclass` VALUES ('1033', '1321145111', '123415');
INSERT INTO `sclass` VALUES ('1034', '1321145111', '123434');
INSERT INTO `sclass` VALUES ('1035', '1321145112', '123411');
INSERT INTO `sclass` VALUES ('1036', '1321145112', '123412');
INSERT INTO `sclass` VALUES ('1037', '1321145112', '123413');
INSERT INTO `sclass` VALUES ('1038', '1321145112', '123415');
INSERT INTO `sclass` VALUES ('1039', '1321145112', '123434');
INSERT INTO `sclass` VALUES ('1040', '1321145113', '123411');
INSERT INTO `sclass` VALUES ('1041', '1321145113', '123412');
INSERT INTO `sclass` VALUES ('1042', '1321145113', '123413');
INSERT INTO `sclass` VALUES ('1043', '1321145113', '123415');
INSERT INTO `sclass` VALUES ('1044', '1321145113', '123434');
INSERT INTO `sclass` VALUES ('1045', '1321145114', '123411');
INSERT INTO `sclass` VALUES ('1046', '1321145114', '123412');
INSERT INTO `sclass` VALUES ('1047', '1321145114', '123413');
INSERT INTO `sclass` VALUES ('1048', '1321145114', '123415');
INSERT INTO `sclass` VALUES ('1049', '1321145114', '123434');
INSERT INTO `sclass` VALUES ('1050', '1321145115', '123411');
INSERT INTO `sclass` VALUES ('1051', '1321145115', '123412');
INSERT INTO `sclass` VALUES ('1052', '1321145115', '123413');
INSERT INTO `sclass` VALUES ('1053', '1321145115', '123415');
INSERT INTO `sclass` VALUES ('1054', '1321145115', '123434');
INSERT INTO `sclass` VALUES ('1055', '1321145116', '123411');
INSERT INTO `sclass` VALUES ('1056', '1321145116', '123412');
INSERT INTO `sclass` VALUES ('1057', '1321145116', '123413');
INSERT INTO `sclass` VALUES ('1058', '1321145116', '123415');
INSERT INTO `sclass` VALUES ('1059', '1321145116', '123434');
INSERT INTO `sclass` VALUES ('1060', '1321145117', '123411');
INSERT INTO `sclass` VALUES ('1061', '1321145117', '123412');
INSERT INTO `sclass` VALUES ('1062', '1321145117', '123413');
INSERT INTO `sclass` VALUES ('1063', '1321145117', '123415');
INSERT INTO `sclass` VALUES ('1064', '1321145117', '123434');
INSERT INTO `sclass` VALUES ('1065', '1321145118', '123411');
INSERT INTO `sclass` VALUES ('1066', '1321145118', '123412');
INSERT INTO `sclass` VALUES ('1067', '1321145118', '123413');
INSERT INTO `sclass` VALUES ('1068', '1321145118', '123415');
INSERT INTO `sclass` VALUES ('1069', '1321145118', '123434');
INSERT INTO `sclass` VALUES ('1070', null, '123411');
INSERT INTO `sclass` VALUES ('1071', null, '123412');
INSERT INTO `sclass` VALUES ('1072', null, '123413');
INSERT INTO `sclass` VALUES ('1073', null, '123415');
INSERT INTO `sclass` VALUES ('1074', null, '123434');
INSERT INTO `sclass` VALUES ('1075', '1321145120', '123411');
INSERT INTO `sclass` VALUES ('1076', '1321145120', '123412');
INSERT INTO `sclass` VALUES ('1077', '1321145120', '123413');
INSERT INTO `sclass` VALUES ('1078', '1321145120', '123415');
INSERT INTO `sclass` VALUES ('1079', '1321145120', '123434');
INSERT INTO `sclass` VALUES ('1080', '1321145201', '123411');
INSERT INTO `sclass` VALUES ('1081', '1321145201', '123412');
INSERT INTO `sclass` VALUES ('1082', '1321145201', '123413');
INSERT INTO `sclass` VALUES ('1083', '1321145201', '123415');
INSERT INTO `sclass` VALUES ('1084', '1321145201', '123434');
INSERT INTO `sclass` VALUES ('1085', '1321145202', '123411');
INSERT INTO `sclass` VALUES ('1086', '1321145202', '123412');
INSERT INTO `sclass` VALUES ('1087', '1321145202', '123413');
INSERT INTO `sclass` VALUES ('1088', '1321145202', '123415');
INSERT INTO `sclass` VALUES ('1089', '1321145202', '123434');
INSERT INTO `sclass` VALUES ('1090', '1321145203', '123411');
INSERT INTO `sclass` VALUES ('1091', '1321145203', '123412');
INSERT INTO `sclass` VALUES ('1092', '1321145203', '123413');
INSERT INTO `sclass` VALUES ('1093', '1321145203', '123415');
INSERT INTO `sclass` VALUES ('1094', '1321145203', '123434');
INSERT INTO `sclass` VALUES ('1095', '1321145204', '123411');
INSERT INTO `sclass` VALUES ('1096', '1321145204', '123412');
INSERT INTO `sclass` VALUES ('1097', '1321145204', '123413');
INSERT INTO `sclass` VALUES ('1098', '1321145204', '123415');
INSERT INTO `sclass` VALUES ('1099', '1321145204', '123434');
INSERT INTO `sclass` VALUES ('1100', '1321145205', '123411');
INSERT INTO `sclass` VALUES ('1101', '1321145205', '123412');
INSERT INTO `sclass` VALUES ('1102', '1321145205', '123413');
INSERT INTO `sclass` VALUES ('1103', '1321145205', '123415');
INSERT INTO `sclass` VALUES ('1104', '1321145205', '123434');
INSERT INTO `sclass` VALUES ('1105', '1321145206', '123411');
INSERT INTO `sclass` VALUES ('1106', '1321145206', '123412');
INSERT INTO `sclass` VALUES ('1107', '1321145206', '123413');
INSERT INTO `sclass` VALUES ('1108', '1321145206', '123415');
INSERT INTO `sclass` VALUES ('1109', '1321145206', '123434');
INSERT INTO `sclass` VALUES ('1110', '1321145207', '123411');
INSERT INTO `sclass` VALUES ('1111', '1321145207', '123412');
INSERT INTO `sclass` VALUES ('1112', '1321145207', '123413');
INSERT INTO `sclass` VALUES ('1113', '1321145207', '123415');
INSERT INTO `sclass` VALUES ('1114', '1321145207', '123434');
INSERT INTO `sclass` VALUES ('1115', '1321145208', '123411');
INSERT INTO `sclass` VALUES ('1116', '1321145208', '123412');
INSERT INTO `sclass` VALUES ('1117', '1321145208', '123413');
INSERT INTO `sclass` VALUES ('1118', '1321145208', '123415');
INSERT INTO `sclass` VALUES ('1119', '1321145208', '123434');
INSERT INTO `sclass` VALUES ('1120', '1321145209', '123411');
INSERT INTO `sclass` VALUES ('1121', '1321145209', '123412');
INSERT INTO `sclass` VALUES ('1122', '1321145209', '123413');
INSERT INTO `sclass` VALUES ('1123', '1321145209', '123415');
INSERT INTO `sclass` VALUES ('1124', '1321145209', '123434');
INSERT INTO `sclass` VALUES ('1125', '1321145210', '123411');
INSERT INTO `sclass` VALUES ('1126', '1321145210', '123412');
INSERT INTO `sclass` VALUES ('1127', '1321145210', '123413');
INSERT INTO `sclass` VALUES ('1128', '1321145210', '123415');
INSERT INTO `sclass` VALUES ('1129', '1321145210', '123434');
INSERT INTO `sclass` VALUES ('1130', '1321145211', '123411');
INSERT INTO `sclass` VALUES ('1131', '1321145211', '123412');
INSERT INTO `sclass` VALUES ('1132', '1321145211', '123413');
INSERT INTO `sclass` VALUES ('1133', '1321145211', '123415');
INSERT INTO `sclass` VALUES ('1134', '1321145211', '123434');
INSERT INTO `sclass` VALUES ('1135', '1321145212', '123411');
INSERT INTO `sclass` VALUES ('1136', '1321145212', '123412');
INSERT INTO `sclass` VALUES ('1137', '1321145212', '123413');
INSERT INTO `sclass` VALUES ('1138', '1321145212', '123415');
INSERT INTO `sclass` VALUES ('1139', '1321145212', '123434');
INSERT INTO `sclass` VALUES ('1140', '1321145213', '123411');
INSERT INTO `sclass` VALUES ('1141', '1321145213', '123412');
INSERT INTO `sclass` VALUES ('1142', '1321145213', '123413');
INSERT INTO `sclass` VALUES ('1143', '1321145213', '123415');
INSERT INTO `sclass` VALUES ('1144', '1321145213', '123434');
INSERT INTO `sclass` VALUES ('1145', '1321145214', '123411');
INSERT INTO `sclass` VALUES ('1146', '1321145214', '123412');
INSERT INTO `sclass` VALUES ('1147', '1321145214', '123413');
INSERT INTO `sclass` VALUES ('1148', '1321145214', '123415');
INSERT INTO `sclass` VALUES ('1149', '1321145214', '123434');
INSERT INTO `sclass` VALUES ('1150', '1321145215', '123411');
INSERT INTO `sclass` VALUES ('1151', '1321145215', '123412');
INSERT INTO `sclass` VALUES ('1152', '1321145215', '123413');
INSERT INTO `sclass` VALUES ('1153', '1321145215', '123415');
INSERT INTO `sclass` VALUES ('1154', '1321145215', '123434');
INSERT INTO `sclass` VALUES ('1155', '1321145216', '123411');
INSERT INTO `sclass` VALUES ('1156', '1321145216', '123412');
INSERT INTO `sclass` VALUES ('1157', '1321145216', '123413');
INSERT INTO `sclass` VALUES ('1158', '1321145216', '123415');
INSERT INTO `sclass` VALUES ('1159', '1321145216', '123434');
INSERT INTO `sclass` VALUES ('1160', '1321145217', '123411');
INSERT INTO `sclass` VALUES ('1161', '1321145217', '123412');
INSERT INTO `sclass` VALUES ('1162', '1321145217', '123413');
INSERT INTO `sclass` VALUES ('1163', '1321145217', '123415');
INSERT INTO `sclass` VALUES ('1164', '1321145217', '123434');
INSERT INTO `sclass` VALUES ('1165', '1321145301', '123411');
INSERT INTO `sclass` VALUES ('1166', '1321145301', '123412');
INSERT INTO `sclass` VALUES ('1167', '1321145301', '123413');
INSERT INTO `sclass` VALUES ('1168', '1321145301', '123415');
INSERT INTO `sclass` VALUES ('1169', '1321145301', '123434');
INSERT INTO `sclass` VALUES ('1170', '1321145302', '123411');
INSERT INTO `sclass` VALUES ('1171', '1321145302', '123412');
INSERT INTO `sclass` VALUES ('1172', '1321145302', '123413');
INSERT INTO `sclass` VALUES ('1173', '1321145302', '123415');
INSERT INTO `sclass` VALUES ('1174', '1321145302', '123434');
INSERT INTO `sclass` VALUES ('1175', '1321145303', '123411');
INSERT INTO `sclass` VALUES ('1176', '1321145303', '123412');
INSERT INTO `sclass` VALUES ('1177', '1321145303', '123413');
INSERT INTO `sclass` VALUES ('1178', '1321145303', '123415');
INSERT INTO `sclass` VALUES ('1179', '1321145303', '123434');
INSERT INTO `sclass` VALUES ('1180', '1321145304', '123411');
INSERT INTO `sclass` VALUES ('1181', '1321145304', '123412');
INSERT INTO `sclass` VALUES ('1182', '1321145304', '123413');
INSERT INTO `sclass` VALUES ('1183', '1321145304', '123415');
INSERT INTO `sclass` VALUES ('1184', '1321145304', '123434');
INSERT INTO `sclass` VALUES ('1185', '1321145305', '123411');
INSERT INTO `sclass` VALUES ('1186', '1321145305', '123412');
INSERT INTO `sclass` VALUES ('1187', '1321145305', '123413');
INSERT INTO `sclass` VALUES ('1188', '1321145305', '123415');
INSERT INTO `sclass` VALUES ('1189', '1321145305', '123434');
INSERT INTO `sclass` VALUES ('1190', '1321145306', '123411');
INSERT INTO `sclass` VALUES ('1191', '1321145306', '123412');
INSERT INTO `sclass` VALUES ('1192', '1321145306', '123413');
INSERT INTO `sclass` VALUES ('1193', '1321145306', '123415');
INSERT INTO `sclass` VALUES ('1194', '1321145306', '123434');
INSERT INTO `sclass` VALUES ('1195', '1321145307', '123411');
INSERT INTO `sclass` VALUES ('1196', '1321145307', '123412');
INSERT INTO `sclass` VALUES ('1197', '1321145307', '123413');
INSERT INTO `sclass` VALUES ('1198', '1321145307', '123415');
INSERT INTO `sclass` VALUES ('1199', '1321145307', '123434');
INSERT INTO `sclass` VALUES ('1200', '1321145308', '123411');
INSERT INTO `sclass` VALUES ('1201', '1321145308', '123412');
INSERT INTO `sclass` VALUES ('1202', '1321145308', '123413');
INSERT INTO `sclass` VALUES ('1203', '1321145308', '123415');
INSERT INTO `sclass` VALUES ('1204', '1321145308', '123434');
INSERT INTO `sclass` VALUES ('1205', '1321145309', '123411');
INSERT INTO `sclass` VALUES ('1206', '1321145309', '123412');
INSERT INTO `sclass` VALUES ('1207', '1321145309', '123413');
INSERT INTO `sclass` VALUES ('1208', '1321145309', '123415');
INSERT INTO `sclass` VALUES ('1209', '1321145309', '123434');
INSERT INTO `sclass` VALUES ('1210', '1321145310', '123411');
INSERT INTO `sclass` VALUES ('1211', '1321145310', '123412');
INSERT INTO `sclass` VALUES ('1212', '1321145310', '123413');
INSERT INTO `sclass` VALUES ('1213', '1321145310', '123415');
INSERT INTO `sclass` VALUES ('1214', '1321145310', '123434');
INSERT INTO `sclass` VALUES ('1215', '1321145311', '123411');
INSERT INTO `sclass` VALUES ('1216', '1321145311', '123412');
INSERT INTO `sclass` VALUES ('1217', '1321145311', '123413');
INSERT INTO `sclass` VALUES ('1218', '1321145311', '123415');
INSERT INTO `sclass` VALUES ('1219', '1321145311', '123434');
INSERT INTO `sclass` VALUES ('1220', '1321145312', '123411');
INSERT INTO `sclass` VALUES ('1221', '1321145312', '123412');
INSERT INTO `sclass` VALUES ('1222', '1321145312', '123413');
INSERT INTO `sclass` VALUES ('1223', '1321145312', '123415');
INSERT INTO `sclass` VALUES ('1224', '1321145312', '123434');
INSERT INTO `sclass` VALUES ('1225', '1321145313', '123411');
INSERT INTO `sclass` VALUES ('1226', '1321145313', '123412');
INSERT INTO `sclass` VALUES ('1227', '1321145313', '123413');
INSERT INTO `sclass` VALUES ('1228', '1321145313', '123415');
INSERT INTO `sclass` VALUES ('1229', '1321145313', '123434');
INSERT INTO `sclass` VALUES ('1230', '1321145314', '123411');
INSERT INTO `sclass` VALUES ('1231', '1321145314', '123412');
INSERT INTO `sclass` VALUES ('1232', '1321145314', '123413');
INSERT INTO `sclass` VALUES ('1233', '1321145314', '123415');
INSERT INTO `sclass` VALUES ('1234', '1321145314', '123434');
INSERT INTO `sclass` VALUES ('1235', '1321145315', '123411');
INSERT INTO `sclass` VALUES ('1236', '1321145315', '123412');
INSERT INTO `sclass` VALUES ('1237', '1321145315', '123413');
INSERT INTO `sclass` VALUES ('1238', '1321145315', '123415');
INSERT INTO `sclass` VALUES ('1239', '1321145315', '123434');
INSERT INTO `sclass` VALUES ('1240', '1321145316', '123411');
INSERT INTO `sclass` VALUES ('1241', '1321145316', '123412');
INSERT INTO `sclass` VALUES ('1242', '1321145316', '123413');
INSERT INTO `sclass` VALUES ('1243', '1321145316', '123415');
INSERT INTO `sclass` VALUES ('1244', '1321145316', '123434');
INSERT INTO `sclass` VALUES ('1245', '1321145317', '123411');
INSERT INTO `sclass` VALUES ('1246', '1321145317', '123412');
INSERT INTO `sclass` VALUES ('1247', '1321145317', '123413');
INSERT INTO `sclass` VALUES ('1248', '1321145317', '123415');
INSERT INTO `sclass` VALUES ('1249', '1321145317', '123434');
INSERT INTO `sclass` VALUES ('1250', '1321145318', '123411');
INSERT INTO `sclass` VALUES ('1251', '1321145318', '123412');
INSERT INTO `sclass` VALUES ('1252', '1321145318', '123413');
INSERT INTO `sclass` VALUES ('1253', '1321145318', '123415');
INSERT INTO `sclass` VALUES ('1254', '1321145318', '123434');
INSERT INTO `sclass` VALUES ('1255', '1321145401', '123411');
INSERT INTO `sclass` VALUES ('1256', '1321145401', '123412');
INSERT INTO `sclass` VALUES ('1257', '1321145401', '123413');
INSERT INTO `sclass` VALUES ('1258', '1321145401', '123415');
INSERT INTO `sclass` VALUES ('1259', '1321145401', '123434');
INSERT INTO `sclass` VALUES ('1260', '1321145402', '123411');
INSERT INTO `sclass` VALUES ('1261', '1321145402', '123412');
INSERT INTO `sclass` VALUES ('1262', '1321145402', '123413');
INSERT INTO `sclass` VALUES ('1263', '1321145402', '123415');
INSERT INTO `sclass` VALUES ('1264', '1321145402', '123434');
INSERT INTO `sclass` VALUES ('1265', '1321145403', '123411');
INSERT INTO `sclass` VALUES ('1266', '1321145403', '123412');
INSERT INTO `sclass` VALUES ('1267', '1321145403', '123413');
INSERT INTO `sclass` VALUES ('1268', '1321145403', '123415');
INSERT INTO `sclass` VALUES ('1269', '1321145403', '123434');
INSERT INTO `sclass` VALUES ('1270', '1321145404', '123411');
INSERT INTO `sclass` VALUES ('1271', '1321145404', '123412');
INSERT INTO `sclass` VALUES ('1272', '1321145404', '123413');
INSERT INTO `sclass` VALUES ('1273', '1321145404', '123415');
INSERT INTO `sclass` VALUES ('1274', '1321145404', '123434');
INSERT INTO `sclass` VALUES ('1275', null, '123411');
INSERT INTO `sclass` VALUES ('1276', null, '123412');
INSERT INTO `sclass` VALUES ('1277', null, '123413');
INSERT INTO `sclass` VALUES ('1278', null, '123415');
INSERT INTO `sclass` VALUES ('1279', null, '123434');
INSERT INTO `sclass` VALUES ('1280', '1321145406', '123411');
INSERT INTO `sclass` VALUES ('1281', '1321145406', '123412');
INSERT INTO `sclass` VALUES ('1282', '1321145406', '123413');
INSERT INTO `sclass` VALUES ('1283', '1321145406', '123415');
INSERT INTO `sclass` VALUES ('1284', '1321145406', '123434');
INSERT INTO `sclass` VALUES ('1285', '1321145407', '123411');
INSERT INTO `sclass` VALUES ('1286', '1321145407', '123412');
INSERT INTO `sclass` VALUES ('1287', '1321145407', '123413');
INSERT INTO `sclass` VALUES ('1288', '1321145407', '123415');
INSERT INTO `sclass` VALUES ('1289', '1321145407', '123434');
INSERT INTO `sclass` VALUES ('1290', '1321145518', '111111');
INSERT INTO `sclass` VALUES ('1291', '1321145611', '123411');
INSERT INTO `sclass` VALUES ('1292', '1321145611', '123412');
INSERT INTO `sclass` VALUES ('1293', '1321145611', '123413');
INSERT INTO `sclass` VALUES ('1294', '1321145611', '123415');
INSERT INTO `sclass` VALUES ('1295', '1321145611', '123434');
INSERT INTO `sclass` VALUES ('1296', '1321145509', '123411');
INSERT INTO `sclass` VALUES ('1297', '1321145509', '123412');
INSERT INTO `sclass` VALUES ('1298', '1321145509', '123413');
INSERT INTO `sclass` VALUES ('1299', '1321145509', '123415');
INSERT INTO `sclass` VALUES ('1300', '1321145509', '123434');
INSERT INTO `sclass` VALUES ('1301', '1321145534', '123411');
INSERT INTO `sclass` VALUES ('1302', '1321145534', '123412');
INSERT INTO `sclass` VALUES ('1303', '1321145534', '123413');
INSERT INTO `sclass` VALUES ('1304', '1321145534', '123415');
INSERT INTO `sclass` VALUES ('1305', '1321145534', '123434');
INSERT INTO `sclass` VALUES ('1306', '1321145603', '123411');
INSERT INTO `sclass` VALUES ('1307', '1321145603', '123412');
INSERT INTO `sclass` VALUES ('1308', '1321145603', '123413');
INSERT INTO `sclass` VALUES ('1309', '1321145603', '123415');
INSERT INTO `sclass` VALUES ('1310', '1321145603', '123434');
INSERT INTO `sclass` VALUES ('1311', '1321145626', '123411');
INSERT INTO `sclass` VALUES ('1312', '1321145626', '123412');
INSERT INTO `sclass` VALUES ('1313', '1321145626', '123413');
INSERT INTO `sclass` VALUES ('1314', '1321145626', '123415');
INSERT INTO `sclass` VALUES ('1315', '1321145626', '123434');
INSERT INTO `sclass` VALUES ('1316', null, '123411');
INSERT INTO `sclass` VALUES ('1317', null, '123412');
INSERT INTO `sclass` VALUES ('1318', null, '123413');
INSERT INTO `sclass` VALUES ('1319', null, '123415');
INSERT INTO `sclass` VALUES ('1320', null, '123434');
INSERT INTO `sclass` VALUES ('1322', '1321145407', '111111');

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `Sno` varchar(20) NOT NULL COMMENT '学号',
  `Sname` varchar(20) NOT NULL COMMENT '姓名',
  `Spw` varchar(20) NOT NULL COMMENT '密码',
  `Sex` varchar(2) NOT NULL DEFAULT '男' COMMENT '性别',
  `Sclass` varchar(6) DEFAULT NULL COMMENT '班级',
  PRIMARY KEY (`Sno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1321145106', '刘艳琴', '123456', '女', '5');
INSERT INTO `student` VALUES ('1321145108', '许梦玲', '12345', '男', '2');
INSERT INTO `student` VALUES ('1321145109', '叶慧珊', '12345', '男', '5');
INSERT INTO `student` VALUES ('1321145111', '张青', '123456', '男', '5');
INSERT INTO `student` VALUES ('1321145112', '王永辉', '12345', '男', '5');
INSERT INTO `student` VALUES ('1321145113', '甘齐', '12345', '男', '5');
INSERT INTO `student` VALUES ('1321145114', '唐福盛', '12345', '男', '5');
INSERT INTO `student` VALUES ('1321145115', '陈彬', '12345', '男', '5');
INSERT INTO `student` VALUES ('1321145116', '洪安理', '12345', '男', '5');
INSERT INTO `student` VALUES ('1321145117', '杨承文', '12345', '男', '5');
INSERT INTO `student` VALUES ('1321145118', '周训涛', '12345', '男', '5');
INSERT INTO `student` VALUES ('1321145120', '陈文锦', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145201', '伍新亮', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145202', '卢成东', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145203', '涂志均', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145204', '刘健宏', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145205', '蒋庆安', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145206', '陈师法', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145207', '黄永强', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145208', '江志能', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145209', '许劼', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145210', '林宇铭', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145211', '阮树乐', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145212', '魏来', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145213', '邱林', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145214', '张晓龙', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145215', '林源', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145216', '郑闽好', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145217', '杨建国', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145301', '吴定盈', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145302', '林仕伟', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145303', '李冰铅', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145304', '范剑敏', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145305', '姚建辉', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145306', '傅俊强', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145307', '李江', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145308', '严雄敏', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145309', '张渊远', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145310', '罗仁助', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145311', '林贵栩', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145312', '范英睿', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145313', '刘辉煌', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145314', '林文彬', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145315', '郑洪辉', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145316', '马圣骅', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145317', '许芹', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145318', '李华龙', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145401', '陈南荣', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145402', '胡灵锋', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145403', '郑哲宇', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145404', '黄信民', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145406', '张黎征', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145407', '易双俊', '123456', '男', '2');
INSERT INTO `student` VALUES ('1321145509', '方根围', '12345', '男', '5');
INSERT INTO `student` VALUES ('1321145518', '刘福文', '123456', '男', '5');
INSERT INTO `student` VALUES ('1321145534', '林德荣', '123456', '男', '5');
INSERT INTO `student` VALUES ('1321145603', '陈勇东', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145611', '小黑', '12345', '男', '6');
INSERT INTO `student` VALUES ('1321145626', '熊俊植', '123456', '男', '6');

-- ----------------------------
-- Table structure for `suggest`
-- ----------------------------
DROP TABLE IF EXISTS `suggest`;
CREATE TABLE `suggest` (
  `mID` int(11) NOT NULL AUTO_INCREMENT COMMENT '留言板id',
  `mstuID` varchar(20) NOT NULL COMMENT '学生ID',
  `mteaID` varchar(20) NOT NULL COMMENT '老师编号',
  `mess` varchar(200) DEFAULT NULL COMMENT '内容',
  `mdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '提交时间',
  PRIMARY KEY (`mID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of suggest
-- ----------------------------
INSERT INTO `suggest` VALUES ('1', '1321145106', '10120111', 'sa', '2014-03-26 23:56:50');
INSERT INTO `suggest` VALUES ('2', '1321145518', '10120131', 'das<img alt=\"微笑\" src=\"script/xheditor_emot/default/smile.gif\" />', '2014-03-26 22:22:00');
INSERT INTO `suggest` VALUES ('3', '1321145518', '10120111', '<img alt=\"哭\" src=\"script/xheditor_emot/default/cry.gif\" />', '2014-03-25 23:22:11');
INSERT INTO `suggest` VALUES ('4', '1321145518', '11201335', '<img alt=\"哭\" src=\"script/xheditor_emot/default/cry.gif\" />', '2014-03-24 23:22:18');
INSERT INTO `suggest` VALUES ('9', '1321145518', '10121314', '<img alt=\"哭\" src=\"script/xheditor_emot/default/cry.gif\" />', '2014-04-03 03:30:28');
INSERT INTO `suggest` VALUES ('10', '1321145518', '10201315', '&nbsp;<img alt=\"抓狂\" src=\"script/xheditor_emot/default/crazy.gif\" />', '2014-04-03 03:30:46');
INSERT INTO `suggest` VALUES ('11', '1321145518', '10120131', '<img alt=\"微笑\" src=\"script/xheditor_emot/default/smile.gif\" />', '2014-04-09 00:42:24');
INSERT INTO `suggest` VALUES ('12', '1321145518', '10120131', '<img alt=\"哭\" src=\"script/xheditor_emot/default/cry.gif\" />', '2014-04-09 01:20:13');
INSERT INTO `suggest` VALUES ('13', '1321145518', '10201316', '<img alt=\"微笑\" src=\"script/xheditor_emot/default/smile.gif\" />', '2014-04-15 20:20:17');
INSERT INTO `suggest` VALUES ('14', '1321145107', '10120111', '<img alt=\"惊讶\" src=\"script/xheditor_emot/default/ohmy.gif\" />', '2014-04-15 20:22:32');
INSERT INTO `suggest` VALUES ('15', '1321145626', '10120111', '<img alt=\"微笑\" src=\"script/xheditor_emot/default/smile.gif\" />sd&nbsp;', '2014-04-15 22:21:15');
INSERT INTO `suggest` VALUES ('16', '1321145406', '10120111', '老师辛苦了<img alt=\"奋斗\" src=\"script/xheditor_emot/default/struggle.gif\" />', '2014-04-16 23:55:14');
INSERT INTO `suggest` VALUES ('17', '1321145312', '10120111', '<span style=\"background-color: rgb(255, 102, 102);\"><strong><span style=\"font-size:24px;\">为人民服务</span></strong></span>', '2014-04-17 00:08:47');
INSERT INTO `suggest` VALUES ('19', '1321145407', '10120131', '<span style=\"color:#FF0000;\">sh</span>z<img alt=\"吐舌头\" src=\"script/xheditor_emot/default/tongue.gif\" />', '2014-04-17 11:23:23');

-- ----------------------------
-- Table structure for `teacher`
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `teaId` varchar(20) NOT NULL COMMENT '教师编号',
  `teaName` varchar(20) NOT NULL COMMENT '教师名字',
  `teaSex` varchar(10) DEFAULT NULL COMMENT '性别',
  `teaSdept` varchar(20) DEFAULT NULL COMMENT '所属系别',
  `password` varchar(20) NOT NULL DEFAULT '12345' COMMENT '密码',
  PRIMARY KEY (`teaId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('10120111', '任晨烨', '男', '体育学院', '123456');
INSERT INTO `teacher` VALUES ('10120131', '吴凌焰', '男', '软件学院', '123456');
INSERT INTO `teacher` VALUES ('10121313', '赵晓丽', '女', '软件学院', '12345');
INSERT INTO `teacher` VALUES ('10121314', '林凯丽', '女', '人文学院', '123456');
INSERT INTO `teacher` VALUES ('10201315', '陈燕芳', '女', '体育学院', '12345');
INSERT INTO `teacher` VALUES ('10201316', '陈雪丹', '女', '软件学院', '12345');
INSERT INTO `teacher` VALUES ('10201317', '尤银婉', '女', '软件学院', '12345');
INSERT INTO `teacher` VALUES ('10201318', '朱欣晔', '女', '人文学院', '12345');
INSERT INTO `teacher` VALUES ('10201319', '魏勤秀', '女', '体育学院', '12345');
INSERT INTO `teacher` VALUES ('11201307', '曾婷', '男', '软件学院', '12345');
INSERT INTO `teacher` VALUES ('11201312', '刘道荣', '女', '软件学院', '12345');
INSERT INTO `teacher` VALUES ('11201315', '晋泽泽', '女', '人文学院', '12345');
INSERT INTO `teacher` VALUES ('11201316', '杨开元', '男', '人文学院', '12345');
INSERT INTO `teacher` VALUES ('11201317', '段文勇', '男', '软件学院', '12345');
INSERT INTO `teacher` VALUES ('11201318', '鲍严杰', '女', '人文学院', '12345');
INSERT INTO `teacher` VALUES ('11201320', '杜航', '男', '体育学院', '12345');
INSERT INTO `teacher` VALUES ('11201321', '孙煜', '女', '软件学院', '12345');
INSERT INTO `teacher` VALUES ('11201324', '严溦', '男', '体育学院', '12345');
INSERT INTO `teacher` VALUES ('11201325', '王敏全', '女', '软件学院', '12345');
INSERT INTO `teacher` VALUES ('11201327', '黄冬骅', '男', '体育学院', '12345');
INSERT INTO `teacher` VALUES ('11201331', '唐福鼎', '男', '人文学院', '12345');
INSERT INTO `teacher` VALUES ('11201333', '林泳', '男', '体育学院', '12345');
INSERT INTO `teacher` VALUES ('11201334', '郑爽', '女', '人文学院', '12345');
INSERT INTO `teacher` VALUES ('11201335', '陈苗苗', '女', '软件学院', '12345');
